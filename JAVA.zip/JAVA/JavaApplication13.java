package javaapplication160;

/**
 *
 * @author Asus
 */                                                 //  REVERSE NUMBER/////
public class JavaApplication160 {
    static int reverse(int n)
    {
        int rev=0;
        int rem;
         while(n>0){N
             rem=n%10;
             rev=(rev*10)+rem;
             n=n/10;
         }
         return rev;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int n=4526;
        System.out.println("Reversed Number is"+reverse(n));
    }
    
}

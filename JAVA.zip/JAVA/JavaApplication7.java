/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication115;
class NewThread implements Runnable {
Thread t;
NewThread() {
t = new Thread(this, "Demo Thread");
System.out.println("Child thread: " + t);
t.start(); 
}
public void run() {
try {
for(int i = 5; i > 0; i--) {
System.out.println("Child Thread: " + i);
Thread.sleep(500);
}
} catch (InterruptedException e) {
System.out.println("Child interrupted.");
}
System.out.println("Exiting child thread.");
}
}

/**
 *
 * @author Asus
 */
 public class JavaApplication115{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new NewThread ();
        try{
            for(int i=0;i>5;i--){
                System.out.println("Main Thread:"+i);
                Thread.sleep(1000);
                }
        }
 catch (InterruptedException e) {
     System.out.println("Main thread interrupted.");
}
System.out.println("Main thread exiting.");
            }
        }

   

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication2;
import java.util.Scanner;
/**
 *
 * @author Asus
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        
        
        int a[][]=new int[2][2];
    int i,j;
Scanner n1=new Scanner(System.in);
System.out.println("Enter the elements");
for(i=0;i<2;i++)
{
    for(j=0;j<2;j++)
    {
        a[i][j]=n1.nextInt();
    }
}

System.out.println("The Elements Are\n");
for(i=0;i<2;i++)
{
    for(j=0;j<2;j++)
    {
        System.out.print(" " +a[i][j]);
    }
    System.out.println();
}

    }
    
}

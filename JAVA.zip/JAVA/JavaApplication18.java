import java.util.Scanner;
class ss
{
int bs,hra,ta,net;
Scanner n1=new Scanner(System.in);
System.out.println("Enter the salary");
bs=n1.nextInt();
if(bs<2000)
{
ta=(bs*5)/100;
hra=(bs*10)/100;
}
else
if (bs>2000 && bs<5000)
{
ta=(bs*10)/100;
hra=(bs*15)/100;
}
else
if(bs>=5000 && bs<10000)
{
ta=(bs*15)/100;
hra=(bs*20)/100;
}
else
{
ta=(bs*20)/100;
hra=(bs*25)/100;
}
net=hra+ta+bs;
System.out.println("The salary is ="+net);
}
}

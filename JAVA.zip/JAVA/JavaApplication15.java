package javaapplication171;
class Box{
    double width;
    double depth;
    double height;
}

public class JavaApplication171 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Box myBox1 =new Box();
        Box myBox2=new Box();
        double vol;
        
        myBox1.width=10;
        myBox1.depth=20;
        myBox1.height=15;
        
        myBox2.depth=4;
        myBox2.height=8;
        myBox2.width=5;
        
        vol=myBox1.width*myBox1.height*myBox1.depth;
        System.out.println("Volume is"+vol);
        
        vol=myBox2.width*myBox2.height*myBox2.depth;
        System.out.println("Volume is"+vol);
    }
    
}
